var iloscInput = document.getElementById("iloscBiletow");
var cenaInput = document.getElementById("kwota");
iloscInput.value = localStorage.getItem("ilosc");
cenaInput.value = localStorage.getItem("cena");
