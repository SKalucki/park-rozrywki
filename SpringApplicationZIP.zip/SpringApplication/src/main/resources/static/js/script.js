function successfullyLogout(){
alert("Pomyślnie wylogowano.");

}